# RoboSynChallenge 2026 technical report

The template uses the official NeurIPS 2026 style with a RoboSynChallenge 2026 footer. Replace the bracketed prompts with your team's content and use simulation runs for all reported results.

Upload the LaTeX source files to Overleaf and compile main.tex with pdfLaTeX, or run latexmk -pdf main.tex locally.

## Submission

- **Page limit** — At most 6 pages of main content, including figures and tables. References are excluded from this limit and may use additional pages.
- **Deadline** — November 15, 2026 (Anywhere on Earth, AoE).
- **Submission** — Submit the report PDF together with the code.


